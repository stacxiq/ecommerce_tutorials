import 'package:dio/dio.dart';
import 'package:ecommerce_tutorials/services/network.dart';

class HomeRepository {
  Future<Response> getCategories() async {
    return await Network.dio.get('categories');
  }
  Future<Response> getProducts() async {
    return await Network.dio.get('products');
  }
}
