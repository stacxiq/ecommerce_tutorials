import 'package:flutter/material.dart';

import 'package:ecommerce_tutorials/models/products.dart';

class ProductItem extends StatelessWidget {
  final Product item;
  const ProductItem({
    Key? key,
    required this.item,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Container(
        color: Colors.grey.shade200,
        padding: EdgeInsets.all(8),
        margin: EdgeInsets.symmetric(vertical: 6),
        height: 110,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Image.network(item.images!.first),
                SizedBox(
                  width: 15,
                ),
                Container(
                  width: 150,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        height: 10,
                      ),
                      Text(
                        item.title!,
                        style: TextStyle(
                            fontSize: 15, fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      Text(item.description!,
                          maxLines: 2, textAlign: TextAlign.start),
                      SizedBox(
                        height: 5,
                      ),
                      Text(item.price.toString() + '\$',
                          maxLines: 2, textAlign: TextAlign.start),
                    ],
                  ),
                ),
              ],
            ),
            Container(
              height: 30,
              width: 30,
              decoration:
                  BoxDecoration(color: Colors.white, shape: BoxShape.circle),
              child: Icon(Icons.favorite_outline),
            )
          ],
        ));
  }
}


// ListTile(
//           isThreeLine: true,
//           leading: Image.network(
//             item.images!.first,
//             fit: BoxFit.cover,
//           ),
//           title: Text(item.title!),
//           subtitle: Text(item.description!),
//         )