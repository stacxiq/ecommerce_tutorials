import 'package:avatar_glow/avatar_glow.dart';
import 'package:dio/dio.dart';
import 'package:ecommerce_tutorials/models/category.dart';
import 'package:ecommerce_tutorials/models/products.dart';
import 'package:ecommerce_tutorials/pages/home/widgets/products_item.dart';
import 'package:ecommerce_tutorials/providers/home_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class ProductWidget extends ConsumerWidget {
  List<Product> productsData = [];
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    AsyncValue<Response> products = ref.watch(productsProvider);

    return products.when(
        data: (result) {
          for (var element in result.data) {
            productsData.add(Product.fromJson(element));
          }
          return Container(
            padding: EdgeInsets.all(8),
            margin: EdgeInsets.all(8),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'العروض',
                      style:
                          TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                    ),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'عرض الكل',
                          style: TextStyle(
                              fontSize: 14, fontWeight: FontWeight.bold),
                        ),
                        SizedBox(
                          width: 2,
                        ),
                        Icon(
                          Icons.arrow_forward_ios,
                          size: 12,
                        )
                      ],
                    )
                  ],
                ),
                Container(
                  width: MediaQuery.of(context).size.width * 0.95,
                  child: ListView.builder(
                    itemCount: 3,
                    shrinkWrap: true,
                    physics: NeverScrollableScrollPhysics(),
                    itemBuilder: (context, int index) {
                      return ProductItem(item: productsData[index]);
                      // return Container(
                      //   height: 70,
                      //   margin: EdgeInsets.all(2),
                      //   width: 250,
                      //   child: Image.network(productsData[index].images!.first),
                      // );
                    },
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        'اهلا بكم داخل تطبيق دكاني ',
                        style: TextStyle(
                            fontSize: 14, fontWeight: FontWeight.bold),
                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width * 0.95,
                      child: DefaultTabController(
                        initialIndex: 1,
                        length: 4,
                        child: Column(
                          children: [
                            TabBar(
                              tabs: [
                                Tab(
                                  child: Container(
                                    child: Column(
                                      children: [
                                        Text(
                                          'اطفال',
                                          style: TextStyle(color: Colors.black),
                                        ),
                                        SizedBox(height: 2),
                                        Icon(
                                          Icons.child_care,
                                          color: Colors.red,
                                        )
                                      ],
                                    ),
                                  ),
                                ),
                                Tab(
                                  child: Container(
                                    child: Text(
                                      'حقائب',
                                      style: TextStyle(color: Colors.black),
                                    ),
                                  ),
                                ),
                                Tab(
                                  child: Container(
                                    child: Text(
                                      'ادوات',
                                      style: TextStyle(color: Colors.black),
                                    ),
                                  ),
                                ),
                                Tab(
                                  child: Container(
                                    child: Text(
                                      'عطور',
                                      style: TextStyle(color: Colors.black),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            Container(
                              width: MediaQuery.of(context).size.width * 0.95,
                              height: 400,
                              child: TabBarView(
                                physics: BouncingScrollPhysics(),
                                children: [
                                  Center(
                                    child: Text("اطفال"),
                                  ),
                                  Center(
                                    child: Text("حقائب"),
                                  ),
                                  Center(
                                    child: Text("ادوات"),
                                  ),
                                  Center(
                                    child: Text("عطور"),
                                  ),
                                ],
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          );
        },
        error: (err, stack) => Text('Error: $err'),
        loading: () {
          return Container(
            padding: EdgeInsets.all(6),
            child: Center(
              child: CircularProgressIndicator(),
            ),
          );
        });
  }
}
