import 'package:avatar_glow/avatar_glow.dart';
import 'package:dio/dio.dart';
import 'package:ecommerce_tutorials/models/category.dart';
import 'package:ecommerce_tutorials/providers/home_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class CategoryWidget extends ConsumerWidget {
  List<Category> categoriesData = [];
  @override
  Widget build(BuildContext context, WidgetRef ref) {
        AsyncValue<Response> categories = ref.watch(categoryProvider);

    // TODO: implement build
    return categories.when(
        data: (response) {
          categoriesData.clear();
          for (var element in response.data) {
            categoriesData.add(Category.fromJson(element));
          }
          return Column(
            children: [
              Container(
                padding: EdgeInsets.all(8),
                height: 125,
                child: ListView.builder(
                  itemCount: categoriesData.length,
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (context, int index) {
                    return Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(4.0),
                          child: AvatarGlow(
                            startDelay: Duration(milliseconds: 1000),
                            glowColor: Colors.red,
                            endRadius: 37.0,
                            duration: Duration(milliseconds: 2000),
                            repeat: true,
                            animate: true,
                            showTwoGlows: true,
                            repeatPauseDuration: Duration(milliseconds: 300),
                            shape: BoxShape.circle,
                            curve: Curves.fastOutSlowIn,
                            child: Material(
                              elevation: 8.0,
                              shape: CircleBorder(),
                              color: Colors.transparent,
                              child: CircleAvatar(
                                radius: 35,
                                backgroundImage:
                                    NetworkImage(categoriesData[index].image!),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 5,
                        ),
                        Text(
                          categoriesData[index].name!,
                          style: TextStyle(
                              color: Colors.black,
                              fontSize: 14,
                              fontWeight: FontWeight.bold),
                        )
                      ],
                    );
                  },
                ),
              ),
              Container(
                height: 20,
                color: Colors.grey.shade300,
              ),
              SizedBox(
                height: 10,
              ),

              // banner

              Container(
                height: 250,
                width: double.infinity,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: 3,
                  itemBuilder: (context, int index) {
                    return Stack(
                      children: [
                        Container(
                          height: 230,
                          width: 380,
                          padding: EdgeInsets.all(4),
                          margin: EdgeInsets.all(2),
                          child: FittedBox(
                            fit: BoxFit.fitWidth,
                            child: Stack(
                              children: [
                                Image.network(
                                  categoriesData[index].image!,
                                ),
                              ],
                            ),
                          ),
                        ),
                        Positioned(
                          top: 0,
                          bottom: 0,
                          left: 0,
                          right: 0,
                          child: Container(
                            height: 250,
                            width: 380,
                            padding: EdgeInsets.all(2),
                            margin: EdgeInsets.all(2),
                            color: Colors.red.withOpacity(0.3),
                          ),
                        ),
                        Positioned(
                          bottom: 15,
                          right: 20,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                categoriesData[index].name!,
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 18,
                                  color: Colors.white,
                                ),
                              ),
                              Text(
                                'تخفيض ٥٠ ٪ ',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                  color: Colors.white,
                                ),
                              ),
                              ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                      primary: Colors.red),
                                  onPressed: () {},
                                  child: Text('تصفح'))
                            ],
                          ),
                        ),
                      ],
                    );
                  },
                ),
              )
            ],
          );
        },
        error: (err, stack) => Text('Error: $err'),
        loading: () {
          return CircularProgressIndicator();
        });
  }
}
