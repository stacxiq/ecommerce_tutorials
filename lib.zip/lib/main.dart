import 'package:ecommerce_tutorials/ecommerce_app.dart';
import 'package:ecommerce_tutorials/init_app.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

void main() {
  InitiaalizeApp.init_app();
  runApp(ProviderScope(child: EcommerceApp()));
}
