import 'package:ecommerce_tutorials/services/network.dart';

class InitiaalizeApp {
  static init_app() {
    Network.initializeInterceptors();
  }
}
